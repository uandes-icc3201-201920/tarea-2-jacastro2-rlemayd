# virtmem
Operating Systems and Networks - Virtual Memory Assignment (Tarea 2)

### Patrón 1:
###### (Cantidad de faltas de páginas/ Cantidad de lecturas a disco/ Cantidad de escrituras a disco)
| Algoritmo | 5 marcos | 50 marcos | 100 marcos |
| :---         |     :---:      |     :---:      |          ---: |
| Rand   | 200 / 100 / 95     | 200 / 100 / 50    | 200 / 100 / 0    |
| FIFO     | 200 / 100 / 95       | 200 / 100 / 50      | 200 / 100 / 0    |

### Patrón 2:
###### (Cantidad de faltas de páginas/ Cantidad de lecturas a disco/ Cantidad de escrituras a disco)
| Algoritmo | 5 marcos | 50 marcos | 100 marcos |
| :---         |     :---:      |     :---:      |          ---: |
| Rand   | 778188 / 389094 / 389089     | 409706 / 204853 / 204803    | 200 / 100 / 0    |
| FIFO     | 778.178 / 389.089 / 389.084       | 408986 / 204493 / 204.443      | 200 / 100 / 0    |

### Patrón 3:
###### (Cantidad de faltas de páginas/ Cantidad de lecturas a disco/ Cantidad de escrituras a disco)
| Algoritmo | 5 marcos | 50 marcos | 100 marcos |
| :---         |     :---:      |     :---:      |          ---: |
| Rand   | 155.740 / 77.870 / 77.865     | 82040 / 41020 / 40970    | 200 / 100 / 0    |
| FIFO     | 155.798 / 77.899 / 77.894       | 81.346 / 40.673 / 40.623      | 200 / 100 / 0    |
