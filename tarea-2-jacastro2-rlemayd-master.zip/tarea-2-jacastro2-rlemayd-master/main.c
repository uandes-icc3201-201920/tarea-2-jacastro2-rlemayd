#include "page_table.h"
#include "disk.h"
#include "program.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <time.h>

const char* algoritmo;

int nframes;
char *physmem;
struct disk *disk = NULL;

//Contadores
int cantidad_falta_de_paginas = 0;
int cantidad_lectura_de_disco = 0;
int cantidad_escritura_en_disco = 0;

//estructura que representa un marco
typedef struct
{
	int numero;
	int bit;
}marco;

//lista de marcos
marco* marcos;
//arreglo auxiliar para el fifo
int *queue;

//declaro la funcion reemplazo_rand para la funcion page_fault_handler, esta funcion sera definida al final del codigo
void reemplazo_rand( struct page_table *pt, int page);
//declaro la funcion FIFO para la funcion page_fault_handler, esta funcion sera definida al final del codigo
void FIFO( struct page_table *pt, int page);

void page_fault_handler( struct page_table *pt, int page)
{
	cantidad_falta_de_paginas++;
	//printf("\npage fault on page #%d",page);
	if(strcmp(algoritmo,"rand")==0)
	{
		//printf("\nejecutar rand");
		reemplazo_rand(pt,page);
	}
	else if (strcmp(algoritmo,"FIFO"))
	{
		//printf("\nejecutar FIFO");
		FIFO(pt,page);
	}
	else
	{
		printf("\ningrese un algoritmo valido, programa abortado");
		exit(1);
	}
}

void resumen(const char* alg,const char* prog, int pages, int frames)
{
	printf("algoritmo utilizado: %s\n",alg);
	printf("programa de acceso a memoria utilizado: %s\n",prog);
	printf("sumario del programa:\n");
	printf(" _______________________________________________________________________\n");
	printf("|Nºpags\t|Nºframes\t|Nºfaltas\t|Nºlecturas\t|Nºescrituras\t|\n");
	printf("|%d\t|%d\t\t|%d\t\t|%d\t\t|%d\t\t|\n",pages,frames,cantidad_falta_de_paginas,cantidad_lectura_de_disco,cantidad_escritura_en_disco);
	printf(" -----------------------------------------------------------------------\n");
}

int main( int argc, char *argv[] )
{
	if(argc!=5) {
		printf("\nuse: virtmem <npages> <nframes> <lru|fifo> <access pattern>\n");
		return 1;
	}
	
	int npages = atoi(argv[1]);
	nframes = atoi(argv[2]);
	const char *program = argv[4];
	algoritmo = argv[3];
	
	marcos = malloc(nframes*sizeof(marco));//definimos el espacio que tomara el arreglo de marcos
	queue = malloc(nframes*sizeof(int));//definimos el espacio que tomara el arreglo auxiliar

	disk = disk_open("myvirtualdisk",npages);
	if(!disk) {
		fprintf(stderr,"couldn't create virtual disk: %s\n",strerror(errno));
		return 1;
	}


	struct page_table *pt = page_table_create( npages, nframes, page_fault_handler );
	if(!pt) {
		fprintf(stderr,"couldn't create page table: %s\n",strerror(errno));
		return 1;
	}

	char *virtmem = page_table_get_virtmem(pt);

	physmem = page_table_get_physmem(pt);

	if(!strcmp(program,"pattern1")) {
		access_pattern1(virtmem,npages*PAGE_SIZE);

	} else if(!strcmp(program,"pattern2")) {
		access_pattern2(virtmem,npages*PAGE_SIZE);

	} else if(!strcmp(program,"pattern3")) {
		access_pattern3(virtmem,npages*PAGE_SIZE);

	} else {
		fprintf(stderr,"unknown program: %s\n",argv[4]);

	}

	page_table_delete(pt);
	disk_close(disk);
	
	free(marcos);//liberamos el arreglo de marcos
	free(queue);

	resumen(algoritmo, program, npages, nframes);
	
	return 0;
}

// algoritmo RAND
void reemplazo_rand( struct page_table *pt, int page)
{
	//obtenemos el marco y los bits por la funcion entregada en el enunciado
	int frame,bits;
	page_table_get_entry(pt,page,&frame,&bits);
	//printf("\nframe:%d\nbits:%d",frame,bits);
		
	if(bits==0)//si los bits son 0 la pagina no esta cargada en memoria, por ende tendremos que cargarla
	{
		//printf("\npagina no cargada en memoria");
		srand(time(0));
		int randframe = (rand() % nframes);//frame al azar al cual se le borrara su pagina
		int disponible = -1;//variable por la cual veremos si hay algun frame disponible
		for(int i = 0; i<nframes; i++)//recorremos los marcos
		{
			if(marcos[i].bit == 0)//si el bit del marco i es 0, esta disponible
			{
				disponible = i;
				break;
			}
		}
		
		if(disponible == -1)//si no hay frames disponibles
		{
			//printf("\nno hay frames disponibles");
			bits = PROT_READ;//el marco tendra bits de proteccion de lectura
			
			//procedemos a sobreescribir las pagina random
			disk_write(disk, marcos[randframe].numero, &physmem[randframe*PAGE_SIZE]);//escribimos lo que este en la pagina al disco
			cantidad_escritura_en_disco++;
			page_table_set_entry(pt, marcos[randframe].numero, randframe, 0);//hacemos un update a la tabla de paginas, dejando "la pagina en blanco"
			marcos[randframe].bit = 0;//reflejamos estos cambios en la lista de marcos
			marcos[randframe].bit=bits;//ponemos el bit del marco random igual que la variable bits
			marcos[randframe].numero = page;
			//sobreescribimos la nueva pagina con los respectivos parametros
			page_table_set_entry(pt,page,randframe,bits);
			disk_read(disk,page, &physmem[randframe*PAGE_SIZE]);//leemos del disco al marco random	
			cantidad_lectura_de_disco++;	
		}
		else
		{
			//printf("\nframe disponible");
			bits = PROT_READ;//el marco tendra bits de proteccion de lectura
			disk_read(disk,page, &physmem[disponible*PAGE_SIZE]);//leemos del disco al marco disponible
			cantidad_lectura_de_disco++;
			marcos[disponible].bit=bits;//ponemos el bit del marco random igual que la variable bits
			marcos[disponible].numero = page;
			//sobreescribimos la nueva pagina con los respectivos parametros
			page_table_set_entry(pt,page,disponible,bits);
		}
		
	}
	else if(bits != 0)//pagina cargada en memoria
	{
		//printf("\npagina ya cargada en memoria");
		//si la pagina ya esta cargada, significa que ahora se requiere de operaicones de escritura
		bits = PROT_READ | PROT_WRITE;//le damos permisos de lectura y escritura
		//utilizamos de indice para el array de marcos el mismo frame entregado y actualizamos los valores
		marcos[frame].numero = page;
		marcos[frame].bit = bits;
		page_table_set_entry(pt,page,frame,bits);
	}
}

//para una estructura fifo conviene definir el primer y ultimo elemento en orden de llegada
int head = 0;//head sera el indice del ultimo dato ingresado
int tail = 0;//tail sera el indice del primer dato ingresado
//junto a esto se define un arreglo auxiliar para el fifo

//algoritmo FIFO
void FIFO( struct page_table *pt, int page)
{
	//obtenemos el marco y los bits por la funcion entregada en el enunciado
	int frame,bits;
	page_table_get_entry(pt,page,&frame,&bits);
	//printf("\nframe:%d\nbits:%d",frame,bits);
	
	if(bits==0)//si los bits son 0 la pagina no esta cargada en memoria, por ende tendremos que cargarla
	{
		//printf("\npagina no cargada en memoria");
		int disponible = -1;//variable por la cual veremos si hay algun frame disponible
		for(int i = 0; i<nframes; i++)//recorremos los marcos
		{
			if(marcos[i].bit == 0)//si el bit del marco i es 0, esta disponible
			{
				disponible = i;
				break;
			}
		}
		if(disponible == -1)//si no hay frames disponibles
		{
			//printf("\nno hay frames disponibles");
			bits = PROT_READ;//el marco tendra bits de proteccion de lectura
			int framefifo = queue[head];
			//procedemos a sobreescribir las pagina random:
			disk_write(disk, marcos[framefifo].numero, &physmem[framefifo*PAGE_SIZE]);//escribimos lo que este en la pagina al disco
			cantidad_escritura_en_disco++;
			page_table_set_entry(pt, marcos[framefifo].numero, framefifo, 0);//hacemos un update a la tabla de paginas, dejando "la pagina en blanco"
			marcos[framefifo].bit = 0;//reflejamos estos cambios en la lista de marcos
			head++; //aumentamos el valor del head
			head = head%nframes;//usamos el modulo de la cantidad de marcos por si se recorre el array completo
			disk_read(disk,page, &physmem[framefifo*PAGE_SIZE]);//leemos del disco al marco disponible
			cantidad_lectura_de_disco++;
			queue[tail] = framefifo;//hacemos que el frame escogido sea el elemento numero 'tail' de la queue
			tail++;//aumentamos el numero de la tail
			tail = tail%nframes;//hacemos la operacion modulo por si recorremos toda la lista
			marcos[framefifo].numero = page;//actualizamos el numero de pagina del marco
			marcos[framefifo].bit = bits;//actualizamos el bit del marco
			page_table_set_entry(pt,page,framefifo,bits);//seteamos una entry en la tabla de paginas
		}
		else
		{
			//printf("\nframe disponible");
			bits = PROT_READ;//el marco tendra bits de proteccion de lectura
			int framefifo = disponible;//el marco sera el disponible encontrado
			disk_read(disk,page, &physmem[framefifo*PAGE_SIZE]);//leemos del disco al marco disponible
			cantidad_lectura_de_disco++;
			queue[tail] = framefifo;//hacemos que el frame escogido sea el elemento numero 'tail' de la queue
			tail++;//aumentamos el numero de la tail
			tail = tail%nframes;//hacemos la operacion modulo por si recorremos toda la lista
			marcos[framefifo].numero = page;//actualizamos el numero de pagina del marco
			marcos[framefifo].bit = bits;//actualizamos el bit del marco
			page_table_set_entry(pt,page,framefifo,bits);//seteamos una entry en la tabla de paginas
		}
	}
	else if(bits != 0)//pagina cargada en memoria
	{
		//printf("\npagina ya cargada en memoria");
		//si la pagina ya esta cargada, significa que ahora se requiere de operaicones de escritura
		bits = PROT_READ | PROT_WRITE;//le damos permisos de lectura y escritura
		//utilizamos de indice para el array de marcos el mismo frame entregado y actualizamos los valores
		marcos[frame].numero = page;
		marcos[frame].bit = bits;
		page_table_set_entry(pt,page,frame,bits);
	}
}
